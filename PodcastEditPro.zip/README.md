# PodcastEdit Pro

Automated podcast/video editing skill for Capafy. Transforms raw recordings into polished episodes in minutes.

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Install FFmpeg
**Windows (using Chocolatey):**
```bash
choco install ffmpeg
```

**Mac (using Homebrew):**
```bash
brew install ffmpeg
```

**Linux (Debian/Ubuntu):**
```bash
sudo apt update && sudo apt install ffmpeg
```

### 3. Run the Skill
```bash
python edit_podcast.py --input raw_podcast.mp4 --output ./output/
```

## Configuration

Copy `config.example.json` to `config.json` and customize:

```json
{
  "brand_name": "Your Podcast Name",
  "filler_words": ["um", "uh", "like"],
  "min_silence_duration": 1.0,
  "intro_path": "./assets/intro.mp3",
  "outro_path": "./assets/outro.mp3"
}
```

## Command Line Options

```
--input PATH          Input video/audio file (required)
--output PATH         Output directory (required)
--config PATH         Path to config.json
--intro PATH          Intro audio/video file
--outro PATH          Outro audio/video file
--brand NAME          Brand name for show notes
--filler-words LIST   Comma-separated filler words
--min-silence SECS    Minimum silence duration to remove
--generate-clips N    Number of social clips to generate
```

## Example Workflows

### Basic Cleanup
```bash
python edit_podcast.py --input interview.mp4 --output ./final/
```

### With Branding
```bash
python edit_podcast.py \
  --input interview.mp4 \
  --output ./final/ \
  --brand "Tech Talks Daily" \
  --intro ./assets/intro.mp3 \
  --outro ./assets/outro.mp3
```

### Custom Filler Words
```bash
python edit_podcast.py \
  --input interview.mp4 \
  --output ./final/ \
  --filler-words "um,uh,like,you know,so,actually,basically"
```

## Output Files

- `edited_episode.mp4` - Final video
- `show_notes.md` - Markdown show notes with chapters
- `transcript.srt` - Timestamped transcript (future)
- `clip_001.mp4` - Social media clips (if enabled)

## Troubleshooting

**FFmpeg not found**: Ensure FFmpeg is installed and in your system PATH.

**Out of memory**: Use a smaller Whisper model (change "small" to "base" in edit_podcast.py).

**Slow processing**: Use GPU acceleration by changing `device="cpu"` to `device="cuda"` in the WhisperModel initialization.

## Capafy Publishing

To publish this skill on Capafy:

1. Zip the `PodcastEditPro` folder
2. Upload to Capafy Publisher Dashboard
3. Set price (suggested: $4.99/episode or $29/month subscription)
4. Add screenshots of the workflow
5. Write a compelling description highlighting 80-90% time savings

## License

MIT License - Feel free to modify and sell.
