#!/usr/bin/env python3
"""
Demo script for PodcastEdit Pro
Creates a sample audio file and processes it to demonstrate the skill
"""

import os
import sys
import numpy as np
import soundfile as sf
from pydub import AudioSegment
from pydub.generators import Sine

def create_demo_audio(output_path: str, duration_seconds: int = 60):
    """Create a demo audio file with filler words and silence"""
    print(f"Creating demo audio file ({duration_seconds}s)...")
    
    # Sample text with filler words (we'll simulate speech with tones)
    # In real use, this would be actual speech
    sample_rate = 16000
    
    # Create a silent base
    audio = np.zeros(int(duration_seconds * sample_rate))
    
    # Add some "speech-like" segments (using sine waves as placeholder)
    # Segment 1: "Hello everyone welcome to the podcast" (0-10s)
    t = np.linspace(0, 10, int(10 * sample_rate))
    speech1 = 0.3 * np.sin(2 * np.pi * 200 * t)  # Low hum for "speech"
    audio[0:len(speech1)] += speech1
    
    # Add filler word "um" at 2s
    t_um = np.linspace(2, 2.3, int(0.3 * sample_rate))
    um_sound = 0.2 * np.sin(2 * np.pi * 300 * t_um)
    audio[int(2 * sample_rate):int(2.3 * sample_rate)] += um_sound
    
    # Segment 2: "Today we're going to talk about AI" (10-20s)
    t2 = np.linspace(10, 20, int(10 * sample_rate))
    speech2 = 0.3 * np.sin(2 * np.pi * 250 * t2)
    audio[int(10 * sample_rate):int(20 * sample_rate)] += speech2
    
    # Add filler "uh" at 15s
    t_uh = np.linspace(15, 15.4, int(0.4 * sample_rate))
    uh_sound = 0.2 * np.sin(2 * np.pi * 350 * t_uh)
    audio[int(15 * sample_rate):int(15.4 * sample_rate)] += uh_sound
    
    # Segment 3: Long silence (20-25s)
    # Already silent
    
    # Segment 4: "So basically AI is changing everything" (25-35s)
    t3 = np.linspace(25, 35, int(10 * sample_rate))
    speech3 = 0.3 * np.sin(2 * np.pi * 225 * t3)
    audio[int(25 * sample_rate):int(35 * sample_rate)] += speech3
    
    # Add filler "like" at 30s
    t_like = np.linspace(30, 30.25, int(0.25 * sample_rate))
    like_sound = 0.2 * np.sin(2 * np.pi * 400 * t_like)
    audio[int(30 * sample_rate):int(30.25 * sample_rate)] += like_sound
    
    # Segment 5: Short silence (35-36s)
    # Already silent
    
    # Segment 6: "Thanks for listening" (36-40s)
    t4 = np.linspace(36, 40, int(4 * sample_rate))
    speech4 = 0.3 * np.sin(2 * np.pi * 275 * t4)
    audio[int(36 * sample_rate):int(40 * sample_rate)] += speech4
    
    # Save as WAV
    sf.write(output_path, audio, sample_rate)
    print(f"✅ Demo audio created: {output_path}")
    return output_path

def run_demo():
    """Run the full demo pipeline"""
    print("=" * 60)
    print("PodcastEdit Pro - Demo")
    print("=" * 60)
    
    # Create demo directory
    os.makedirs("demo_output", exist_ok=True)
    
    # Step 1: Create demo audio
    demo_audio = "demo_output/demo_podcast.wav"
    create_demo_audio(demo_audio, duration_seconds=40)
    
    # Step 2: Create config
    config = {
        "brand_name": "Demo Podcast",
        "filler_words": ["um", "uh", "like"],
        "min_silence_duration": 1.0,
        "silence_threshold": -40,
        "generate_clips": 2
    }
    
    import json
    with open("demo_output/config.json", 'w') as f:
        json.dump(config, f, indent=2)
    
    # Step 3: Run the editor
    print("\nRunning PodcastEdit Pro...")
    from edit_podcast import PodcastEditor
    
    editor = PodcastEditor("demo_output/config.json")
    editor.process(demo_audio, "demo_output/final")
    
    print("\n" + "=" * 60)
    print("Demo complete! Check demo_output/final/ for results")
    print("=" * 60)

if __name__ == "__main__":
    run_demo()
