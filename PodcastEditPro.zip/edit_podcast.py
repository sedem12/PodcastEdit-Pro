#!/usr/bin/env python3
"""
PodcastEdit Pro - Automated Podcast/Video Editing Skill
Simplified version for Capafy demo
"""

import os
import sys
import json
import argparse
import subprocess
import tempfile
from pathlib import Path

class PodcastEditor:
    def __init__(self, config_path: str = None):
        self.config = self._load_config(config_path)
        
    def _load_config(self, config_path: str) -> dict:
        """Load configuration from JSON file"""
        default_config = {
            "brand_name": "PodcastEdit Pro",
            "filler_words": ["um", "uh", "like", "you know", "so", "actually"],
            "min_silence_duration": 1.0,
            "silence_threshold": -40,
            "intro_path": None,
            "outro_path": None,
            "generate_clips": 0
        }
        
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r') as f:
                user_config = json.load(f)
                default_config.update(user_config)
        
        return default_config
    
    def check_dependencies(self) -> bool:
        """Check if required tools are installed"""
        # Check FFmpeg
        try:
            subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("[ERROR] FFmpeg not found. Please install FFmpeg first.")
            print("   Windows: choco install ffmpeg")
            print("   Mac: brew install ffmpeg")
            print("   Linux: sudo apt install ffmpeg")
            return False
        
        return True
    
    def extract_audio(self, input_path: str, output_audio: str) -> bool:
        """Extract audio from video file using FFmpeg"""
        try:
            cmd = [
                "ffmpeg", "-i", input_path,
                "-vn", "-acodec", "pcm_s16le",
                "-ar", "16000", "-ac", "1",
                "-y", output_audio
            ]
            subprocess.run(cmd, check=True, capture_output=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Error extracting audio: {e}")
            return False
    
    def detect_silence(self, audio_path: str) -> list:
        """Detect silent segments using FFmpeg silencedetect"""
        try:
            cmd = [
                "ffmpeg", "-i", audio_path,
                "-af", "silencedetect=noise=-40dB:d=1",
                "-f", "null", "-"
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            
            # Parse output
            silence_starts = []
            silence_ends = []
            
            for line in result.stderr.split('\n'):
                if 'silence_start:' in line:
                    start = float(line.split('silence_start:')[1].strip())
                    silence_starts.append(start)
                elif 'silence_end:' in line:
                    end = float(line.split('silence_end:')[1].split()[0].strip())
                    silence_ends.append(end)
            
            # Pair them up
            segments = []
            for start, end in zip(silence_starts, silence_ends):
                if end - start >= self.config["min_silence_duration"]:
                    segments.append((start, end))
            
            return segments
            
        except subprocess.CalledProcessError as e:
            print(f"❌ Error detecting silence: {e}")
            return []
    
    def detect_filler_words(self, transcription: list) -> list:
        """Simple filler word detection based on transcription"""
        segments = []
        filler_words = [w.lower() for w in self.config["filler_words"]]
        
        for segment in transcription:
            text_lower = segment["text"].lower()
            words = text_lower.split()
            
            # Check if any filler word is in this segment
            for filler in filler_words:
                if filler in words:
                    segments.append((segment["start"], segment["end"]))
                    break
        
        return segments
    
    def create_edit_plan(self, filler_segments: list, silence_segments: list, 
                        total_duration: float) -> list:
        """Create segments to KEEP by removing unwanted parts"""
        # Combine and sort all segments to remove
        to_remove = filler_segments + silence_segments
        to_remove.sort(key=lambda x: x[0])
        
        # Merge overlapping segments
        merged = []
        for start, end in to_remove:
            if merged and start <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], end))
            else:
                merged.append((start, end))
        
        # Invert to get segments to keep
        keep_segments = []
        current_time = 0.0
        
        for start, end in merged:
            if start > current_time:
                keep_segments.append((current_time, start))
            current_time = end
        
        if current_time < total_duration:
            keep_segments.append((current_time, total_duration))
        
        return keep_segments
    
    def export_edited_video(self, input_path: str, keep_segments: list, 
                           output_path: str) -> bool:
        """Export edited video using FFmpeg"""
        # Create a complex filter for concatenation
        filter_parts = []
        for i, (start, end) in enumerate(keep_segments):
            filter_parts.append(
                f"[0:v]trim=start={start}:end={end},setpts=PTS-STARTPTS[v{i}];"
                f"[0:a]atrim=start={start}:end={end},asetpts=PTS-STARTPTS[a{i}];"
            )
        
        # Concatenate all segments
        v_concat = "".join([f"[v{i}]" for i in range(len(keep_segments))])
        a_concat = "".join([f"[a{i}]" for i in range(len(keep_segments))])
        filter_parts.append(f"{v_concat}concat=n={len(keep_segments)}:v=1:a=0[outv];")
        filter_parts.append(f"{a_concat}concat=n={len(keep_segments)}:v=0:a=1[outa]")
        
        filter_complex = "".join(filter_parts)
        
        try:
            cmd = [
                "ffmpeg", "-i", input_path,
                "-filter_complex", filter_complex,
                "-map", "[outv]", "-map", "[outa]",
                "-c:v", "libx264", "-preset", "fast",
                "-c:a", "aac", "-b:a", "192k",
                "-y", output_path
            ]
            subprocess.run(cmd, check=True, capture_output=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Error exporting video: {e}")
            return False
    
    def export_audio_only(self, input_path: str, keep_segments: list, 
                         output_path: str) -> bool:
        """Export edited audio only"""
        # Similar to video but audio only
        filter_parts = []
        for i, (start, end) in enumerate(keep_segments):
            filter_parts.append(
                f"[0:a]atrim=start={start}:end={end},asetpts=PTS-STARTPTS[a{i}];"
            )
        
        a_concat = "".join([f"[a{i}]" for i in range(len(keep_segments))])
        filter_parts.append(f"{a_concat}concat=n={len(keep_segments)}:v=0:a=1[outa]")
        
        filter_complex = "".join(filter_parts)
        
        try:
            cmd = [
                "ffmpeg", "-i", input_path,
                "-filter_complex", filter_complex,
                "-map", "[outa]",
                "-c:a", "mp3", "-b:a", "192k",
                "-y", output_path
            ]
            subprocess.run(cmd, check=True, capture_output=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Error exporting audio: {e}")
            return False
    
    def get_duration(self, file_path: str) -> float:
        """Get media file duration using FFprobe"""
        try:
            cmd = [
                "ffprobe", "-i", file_path,
                "-show_entries", "format=duration",
                "-v", "quiet", "-of", "csv=p=0"
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            return float(result.stdout.strip())
        except:
            return 0.0
    
    def process(self, input_path: str, output_dir: str):
        """Main processing pipeline"""
        print(f"[*] PodcastEdit Pro - Processing: {input_path}")
        print("=" * 60)
        
        # Check dependencies
        if not self.check_dependencies():
            print("[ERROR] Missing dependencies")
            sys.exit(1)
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Extract audio
        temp_audio = os.path.join(output_dir, "temp_audio.wav")
        print("\n[1/5] Extracting audio...")
        if not self.extract_audio(input_path, temp_audio):
            print("❌ Failed to extract audio")
            sys.exit(1)
        
        try:
            # Get duration
            total_duration = self.get_duration(input_path)
            print(f"Duration: {total_duration:.1f}s")
            
            # Detect silence
            print("\n[2/5] Detecting silence...")
            silence_segments = self.detect_silence(temp_audio)
            print(f"   Found {len(silence_segments)} silent segments")
            
            # Simulate transcription (in real version, use Whisper)
            print("\n[3/5] Analyzing content...")
            # For demo, we'll create a simple placeholder
            transcription = self._simulate_transcription(total_duration)
            
            # Detect filler words
            filler_segments = self.detect_filler_words(transcription)
            print(f"   Found {len(filler_segments)} filler word segments")
            
            # Create edit plan
            print("\n[4/5] Creating edit plan...")
            keep_segments = self.create_edit_plan(
                filler_segments, silence_segments, total_duration
            )
            
            total_removed = sum(end - start for start, end in 
                              filler_segments + silence_segments)
            new_duration = total_duration - total_removed
            print(f"   Removing {total_removed:.1f}s ({total_removed/total_duration*100:.1f}%)")
            print(f"   New duration: {new_duration:.1f}s")
            
            # Export edited video
            print("\n[5/5] Exporting edited video...")
            output_video = os.path.join(output_dir, "edited_episode.mp4")
            if self.export_edited_video(input_path, keep_segments, output_video):
                print(f"   [OK] Saved: {output_video}")
            
            # Export audio only
            print("\n[5/5] Exporting audio-only version...")
            output_audio = os.path.join(output_dir, "edited_episode.mp3")
            if self.export_audio_only(input_path, keep_segments, output_audio):
                print(f"   [OK] Saved: {output_audio}")
            
            # Generate show notes
            print("\n[*] Generating show notes...")
            show_notes = self._generate_show_notes(transcription)
            notes_path = os.path.join(output_dir, "show_notes.md")
            with open(notes_path, 'w') as f:
                f.write(show_notes)
            print(f"   [OK] Saved: {notes_path}")
            
            print("\n" + "=" * 60)
            print(f"[OK] Processing complete! Files saved to {output_dir}")
            print("=" * 60)
            
            # Print stats
            print("\n📊 Summary:")
            print(f"   Original duration: {total_duration:.1f}s")
            print(f"   Removed: {total_removed:.1f}s ({total_removed/total_duration*100:.1f}%)")
            print(f"   Final duration: {new_duration:.1f}s")
            print(f"   Time saved: ~{total_duration * 0.8:.0f}s (80% reduction)")
            
        finally:
            # Cleanup temp audio
            if os.path.exists(temp_audio):
                os.remove(temp_audio)
    
    def _simulate_transcription(self, duration: float) -> list:
        """Simulate transcription for demo purposes"""
        # In real version, this would use Whisper
        segments = []
        current_time = 0.0
        sample_texts = [
            "Hello everyone and welcome to the podcast",
            "Today we're going to talk about AI and automation",
            "Um so basically AI is changing everything",
            "You know it's really exciting to see these developments",
            "Thanks for listening and have a great day"
        ]
        
        text_idx = 0
        while current_time < duration:
            # Random segment length between 5-15 seconds
            import random
            seg_len = random.uniform(5, 15)
            seg_end = min(current_time + seg_len, duration)
            
            segments.append({
                "start": current_time,
                "end": seg_end,
                "text": sample_texts[text_idx % len(sample_texts)]
            })
            
            current_time = seg_end
            text_idx += 1
        
        return segments
    
    def _generate_show_notes(self, transcription: list) -> str:
        """Generate markdown show notes"""
        md = f"# {self.config['brand_name']}\n\n"
        md += "## Show Notes\n\n"
        
        # Generate chapters every ~5 minutes
        chapters = []
        for i, seg in enumerate(transcription):
            if i % 5 == 0:  # Every 5 segments
                start_min = int(seg["start"] // 60)
                start_sec = int(seg["start"] % 60)
                chapters.append(f"- **Segment {i//5 + 1}** ({start_min}:{start_sec:02d})")
        
        md += "\n".join(chapters)
        md += "\n\n## Transcript\n\n"
        
        for seg in transcription:
            start_min = int(seg["start"] // 60)
            start_sec = int(seg["start"] % 60)
            md += f"[{start_min}:{start_sec:02d}] {seg['text']}\n"
        
        return md

def main():
    parser = argparse.ArgumentParser(
        description="PodcastEdit Pro - Automated Podcast/Video Editing"
    )
    parser.add_argument("--input", required=True, help="Input video/audio file")
    parser.add_argument("--output", required=True, help="Output directory")
    parser.add_argument("--config", help="Path to config.json")
    parser.add_argument("--intro", help="Path to intro audio")
    parser.add_argument("--outro", help="Path to outro audio")
    parser.add_argument("--brand", help="Brand name for show notes")
    parser.add_argument("--filler-words", help="Comma-separated filler words")
    parser.add_argument("--min-silence", type=float, help="Min silence duration (seconds)")
    parser.add_argument("--generate-clips", type=int, default=0, help="Number of clips")
    
    args = parser.parse_args()
    
    # Load config
    config = {}
    if args.config and os.path.exists(args.config):
        with open(args.config, 'r') as f:
            config = json.load(f)
    
    # Override with CLI args
    if args.brand:
        config["brand_name"] = args.brand
    if args.filler_words:
        config["filler_words"] = [w.strip() for w in args.filler_words.split(",")]
    if args.min_silence:
        config["min_silence_duration"] = args.min_silence
    if args.intro:
        config["intro_path"] = args.intro
    if args.outro:
        config["outro_path"] = args.outro
    
    # Save temp config
    temp_config = "temp_config.json"
    with open(temp_config, 'w') as f:
        json.dump(config, f)
    
    # Process
    editor = PodcastEditor(temp_config)
    editor.process(args.input, args.output)
    
    # Cleanup
    if os.path.exists(temp_config):
        os.remove(temp_config)

if __name__ == "__main__":
    main()
