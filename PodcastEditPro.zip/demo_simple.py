#!/usr/bin/env python3
"""
Simple demo for PodcastEdit Pro
Tests the skill with a dummy audio file
"""

import os
import sys
import subprocess
import numpy as np
import soundfile as sf

def create_test_audio(output_path: str):
    """Create a test audio file with known patterns"""
    print("Creating test audio file...")
    
    sample_rate = 16000
    duration = 30  # 30 seconds
    t = np.linspace(0, duration, int(duration * sample_rate))
    
    # Create audio with speech-like patterns and silence
    audio = np.zeros_like(t)
    
    # Segment 1: "Speech" 0-10s
    mask1 = (t >= 0) & (t < 10)
    audio[mask1] = 0.3 * np.sin(2 * np.pi * 200 * t[mask1])
    
    # Segment 2: Silence 10-12s
    # Already zero
    
    # Segment 3: "Speech" with filler 12-20s
    mask2 = (t >= 12) & (t < 20)
    audio[mask2] = 0.3 * np.sin(2 * np.pi * 250 * t[mask2])
    
    # Add "um" at 15s
    mask_um = (t >= 15) & (t < 15.3)
    audio[mask_um] += 0.2 * np.sin(2 * np.pi * 300 * t[mask_um])
    
    # Segment 4: Silence 20-22s
    # Already zero
    
    # Segment 5: "Speech" 22-30s
    mask3 = (t >= 22) & (t < 30)
    audio[mask3] = 0.3 * np.sin(2 * np.pi * 225 * t[mask3])
    
    # Add filler "like" at 25s
    mask_like = (t >= 25) & (t < 25.2)
    audio[mask_like] += 0.2 * np.sin(2 * np.pi * 400 * t[mask_like])
    
    # Save
    sf.write(output_path, audio, sample_rate)
    print(f"[OK] Created test audio: {output_path}")
    return output_path

def run_test():
    """Run a test of the skill"""
    print("=" * 70)
    print("PodcastEdit Pro - Test Run")
    print("=" * 70)
    
    # Create test directory
    os.makedirs("test_output", exist_ok=True)
    
    # Create test audio
    test_audio = "test_output/test_input.wav"
    create_test_audio(test_audio)
    
    # Create config
    config = {
        "brand_name": "Test Podcast",
        "filler_words": ["um", "like"],
        "min_silence_duration": 1.0,
        "silence_threshold": -40
    }
    
    import json
    config_path = "test_output/config.json"
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    
    # Run the skill
    print("\nRunning PodcastEdit Pro...")
    print("-" * 70)
    
    from edit_podcast import PodcastEditor
    
    editor = PodcastEditor(config_path)
    editor.process(test_audio, "test_output/output")
    
    print("\n" + "=" * 70)
    print("[OK] Test complete!")
    print("=" * 70)
    print("\nGenerated files in test_output/output/:")
    for f in os.listdir("test_output/output"):
        print(f"  - {f}")

if __name__ == "__main__":
    run_test()
