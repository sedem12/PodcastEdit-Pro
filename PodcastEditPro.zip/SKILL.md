# PodcastEdit Pro - Automated Podcast/Video Editing

## What This Skill Does

PodcastEdit Pro transforms raw podcast/video recordings into polished, publication-ready episodes in minutes instead of hours. It automatically removes filler words, silences, and dead air while preserving your content's natural flow.

**Perfect for**: Podcasters, YouTubers, interview hosts, and content creators who want professional editing without the time cost or expensive software.

## When to Use This Skill

Use this skill when you have:
- Raw podcast or video interview recordings
- Long-form content that needs cleanup before publishing
- Multiple speakers with inconsistent audio levels
- Need to generate show notes and social clips automatically

**Do NOT use for**: Music production, film editing, or content requiring creative storytelling cuts. This skill handles technical cleanup, not narrative restructuring.

## How It Works

### Input
Upload a video or audio file (MP4, MP3, WAV, MOV). Optionally provide:
- Intro/outro audio or video clips
- Brand name for show notes
- Custom filler words list

### Process
1. **Transcribe** - Converts speech to text with word-level timestamps using Whisper AI
2. **Analyze** - Identifies filler words ("um", "uh", "like") and silent segments
3. **Edit** - Automatically removes unwanted sections and concatenates the rest
4. **Enhance** - Normalizes audio, reduces noise, adds intro/outro
5. **Package** - Generates final video/audio, transcript, show notes, and social clips

### Output
- Edited video file (MP4)
- Audio-only version (MP3)
- Timestamped transcript (SRT)
- Show notes with chapters (Markdown)
- Social media clips (MP4, 60-second highlights)

## How to Use

### Basic Usage
```bash
python edit_podcast.py --input raw_interview.mp4 --output ./final_episode/
```

### Advanced Options
```bash
python edit_podcast.py \
  --input raw_interview.mp4 \
  --output ./final_episode/ \
  --intro intro_music.mp3 \
  --outro outro_music.mp3 \
  --brand "My Awesome Podcast" \
  --filler-words "um,uh,like,you know,so" \
  --min-silence 1.5 \
  --generate-clips 3
```

### Configuration File
Create a `config.json` for repeated use:
```json
{
  "brand_name": "Tech Talks Daily",
  "filler_words": ["um", "uh", "like", "you know", "so", "actually"],
  "min_silence_duration": 1.0,
  "intro_path": "./assets/intro.mp3",
  "outro_path": "./assets/outro.mp3"
}
```

## Technical Details

### Dependencies
- Python 3.9+
- FFmpeg (system install)
- faster-whisper
- moviepy
- numpy
- openai

### Performance
- Processing time: ~15-30 minutes for a 60-minute episode
- Disk space: ~2x input file size during processing
- Memory: 4GB+ recommended for Whisper transcription

### Limitations
- Best performance with clear speech (minimal background noise)
- Supports English (other languages need Whisper model changes)
- Maximum recommended file size: 2GB (longer files need chunking)

## Pricing Suggestions (for Capafy)

- **Per-episode**: $4.99
- **Monthly subscription**: $29/month (up to 10 episodes)
- **Enterprise**: Custom pricing for networks

## Support

For issues or feature requests, contact the skill publisher through Capafy.

---

**Version**: 1.0.0  
**Last Updated**: 2025-09-02
